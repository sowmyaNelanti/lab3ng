export interface USER{
    name:string;
    id:number;
    cost:number;
}