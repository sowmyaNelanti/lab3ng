import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  PID;
  PName;
  PCost;
  POnline;
  PCategory;
  bigBazar;
  dmart;
  reliance;
  storeArray;
  megaStore;
   addProduct() {

    if (!this.PID) {
      alert("Please enter Product Id");
    }
    else if (!this.PName) {
      alert("Please enter Product Name");
    }
    else if (!this.PCost) {
      alert("Please enter Product cost");
    }
    else if (!this.POnline) {
      alert("Please enter Product Pnline");
    }
    else if (!this.PCategory) {
      alert("Please enter Product category");
    }
    else if (!this.bigBazar && !this.dmart && !this.reliance && !this.megaStore) {
      alert("Please select atleast one store");
    }
    else {
      this.storeArray = [];
      if (this.bigBazar) {
        this.storeArray.push("Big bazar");
      }
      if (this.dmart) {
        this.storeArray.push("Dmart");
      }
      if (this.reliance) {
        this.storeArray.push("Reliance");
      }
      if (this.megaStore) {
        this.storeArray.push("Mega store");
      }
      console.log("Product Id:" + this.PID);
       console.log("Product Name:" + this.PName );
       console.log("Product cost:" + this.PCost );
       console.log("Product category:" + this.PCategory );
       console.log("Available in:" + this.storeArray.join());
    }

  }
}
