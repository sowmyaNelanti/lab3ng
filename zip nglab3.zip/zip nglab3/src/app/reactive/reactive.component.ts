import { Component, OnInit } from '@angular/core';
import{USER} from '../user';
import{FormGroup,FormControl,Validators} from '@angular/forms';

@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.css']
})
export class ReactiveComponent implements OnInit {
userList:USER[]=[];
  constructor() { }
 form: FormGroup;

  ngOnInit() {
    this.form=new FormGroup({
      name:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+')]),
       id:new FormControl('',[Validators.required,Validators.pattern('[0-9]+'),Validators.minLength(4),Validators.maxLength(10)]),
       cost:new FormControl('',[Validators.required,Validators.pattern('[0-9]+')]),
       anyOne:new FormControl('',[Validators.required])
    })
  }
  addUser(form){
    console.log(form.value);
  this.userList.push(this.form.value);
  }

}
